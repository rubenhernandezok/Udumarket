import { useEffect, useState, Fragment } from "react"
import Layout from "../../../components/layout/Layout"
import { getSales } from "../services/saleService"

export default function Sales() {

  const [sales, setSales] = useState([])
  const [totalSales, setTotalSales] = useState(0)

  const [filter, setFilter] = useState("all")
  const [expanded, setExpanded] = useState(null)
  const [selectedDate, setSelectedDate] = useState("")

  // 🔥 PAGINACIÓN BACKEND
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 12

  useEffect(() => {
    loadSales()
  }, [currentPage])

  const loadSales = async () => {

    const res = await getSales(currentPage, itemsPerPage)

    // 🔥 CLAVE
    setSales(res.data || [])
    setTotalSales(res.total || 0)
  }

  // 🕒 HORA CORRECTA
  const toLocalDate = (date) => {
    return new Date(date + "Z").toLocaleString("es-AR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    })
  }

  // 📅 SOLO FECHA
  const getLocalDateOnly = (date) => {
    return new Date(date).toLocaleDateString("en-CA", {
      timeZone: "America/Argentina/Buenos_Aires"
    })
  }

  // 🔎 FILTRO
  const filteredSales = sales.filter((sale) => {

    const saleDate = getLocalDateOnly(sale.created_at)

    if (selectedDate) return saleDate === selectedDate

    if (filter === "today") {
      return saleDate === getLocalDateOnly(new Date())
    }

    if (filter === "month") {
      const now = new Date()
      const saleDateObj = new Date(sale.created_at)

      return (
        saleDateObj.getMonth() === now.getMonth() &&
        saleDateObj.getFullYear() === now.getFullYear()
      )
    }

    return true
  })

  // 💰 TOTALES (solo de la página actual)
  const todayTotal = sales
    .filter(s => getLocalDateOnly(s.created_at) === getLocalDateOnly(new Date()))
    .reduce((acc, s) => acc + Number(s.total), 0)

  const totalAll = sales.reduce((acc, s) => acc + Number(s.total), 0)

  // 🔽 EXPANDIR
  const toggleExpand = (id) => {
    setExpanded(expanded === id ? null : id)
  }

  // 🔥 TOTAL PÁGINAS REAL
  const totalPages = Math.ceil(totalSales / itemsPerPage)

  return (

    <Layout>

      <div className="container mt-4">

        <h2>Historial de ventas</h2>

        {/* 💰 CARDS */}
        <div className="row mb-4">

          <div className="col-md-6">
            <div className="card p-3">
              <h6>Ventas de hoy</h6>
              <h4>${todayTotal.toFixed(2)}</h4>
            </div>
          </div>

          <div className="col-md-6">
            <div className="card p-3">
              <h6>Total (página actual)</h6>
              <h4>${totalAll.toFixed(2)}</h4>
            </div>
          </div>

        </div>

        {/* 🔎 FILTRO */}
        <div className="row mb-3">

          <div className="col-md-6">
            <select
              className="form-select"
              value={filter}
              onChange={(e) => {
                setFilter(e.target.value)
                setSelectedDate("")
              }}
            >
              <option value="all">Todas</option>
              <option value="today">Hoy</option>
              <option value="month">Este mes</option>
            </select>
          </div>

          <div className="col-md-6">
            <input
              type="date"
              className="form-control"
              value={selectedDate}
              onChange={(e) => {
                setSelectedDate(e.target.value)
                setFilter("all")
              }}
            />
          </div>

        </div>

        {/* 📋 TABLA */}
        <table className="table table-striped">

          <thead>
            <tr>
              <th>Fecha</th>
              <th>Total</th>
              <th>Pago</th>
              <th></th>
            </tr>
          </thead>

          <tbody>

            {filteredSales.map((sale) => (

              <Fragment key={sale.id}>

                <tr
                  onClick={() => toggleExpand(sale.id)}
                  style={{ cursor: "pointer" }}
                >

                  <td>{toLocalDate(sale.created_at)}</td>
                  <td>${Number(sale.total).toFixed(2)}</td>
                  <td>{sale.payment_method}</td>
                  <td>{expanded === sale.id ? "▲" : "▼"}</td>

                </tr>

                {expanded === sale.id && (
                  <tr>
                    <td colSpan="4">
                      <div className="p-2">
                        {sale.items.map((item, i) => (
                          <div key={i}>
                            {item.product_name} ({item.barcode}) — {item.quantity} x ${item.price}
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}

              </Fragment>

            ))}

          </tbody>

        </table>

        {/* 🔥 PAGINACIÓN */}
        {totalPages > 1 && (
          <div className="d-flex justify-content-center mt-3">

            <button
              className="btn btn-outline-primary me-2"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => prev - 1)}
            >
              ← Anterior
            </button>

            <span className="align-self-center">
              Página {currentPage} de {totalPages}
            </span>

            <button
              className="btn btn-outline-primary ms-2"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => prev + 1)}
            >
              Siguiente →
            </button>

          </div>
        )}

      </div>

    </Layout>
  )
}